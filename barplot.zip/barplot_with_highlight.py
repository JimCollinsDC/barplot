import matplotlib.pyplot as plt
import numpy as np


class BarHighlightAboveThreshold(object):
    def __init__(self, x, height, threshold, facecolor, edgecolor):
        self._x = x
        self._height = height
        self._threshold = threshold
        self._facecolor = facecolor
        self._edgecolor = edgecolor

    def _set_barchart(self):
        plot = plt.bar(self._x,
                       self._height,
                       facecolor=self._facecolor,
                       edgecolor=self._edgecolor)
        return plot

    def _get_height_coord_list(self):
        plot = self._set_barchart()
        heights = [plot[i].get_height() for i in range(len(plot))]

        i=0
        height_coord_list = list()
        for height in heights:
            if height > self._threshold:
                plot[i].set_color('red')
                height_coord = (plot[i].get_x()+plot[i].get_width()/2,plot[i].get_height())
                height_coord_list.append(height_coord)
            i+=1
        return height_coord_list
        
    def _set_annotation(self):
        height_coord_list = self._get_height_coord_list()
        for height_coord in height_coord_list:
            plt.annotate('Above threshold',
                         xy=(height_coord[0], height_coord[1]),
                         xytext=(height_coord[0], height_coord[1]),
                         rotation=+45)

    def show(self):
        self._set_annotation()
        plt.show()
    
if __name__ == '__main__':
    x = [i for i in range(30)]
    height = np.random.randint(0,10,30)
    threshold = 7
    facecolor='#2ab0ff'
    edgecolor='#e0e0e0'
    barplot = BarHighlightAboveThreshold(x, height, threshold, facecolor, edgecolor)
    barplot.show()
    