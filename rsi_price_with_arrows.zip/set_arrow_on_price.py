import matplotlib.pyplot as plt
import numpy as np
from datetime import date
from matplotlib.widgets import MultiCursor


class SetArrowOnPriceBasedOnRsi(object):
    def __init__(self, t, minimum, maximum, rsi_color, dia_color):
        self._t = t
        self._min = minimum
        self._max = maximum
        self._rsi_color = rsi_color
        self._dia_color = dia_color
        self._fig, (self._ax1, self._ax2) = plt.subplots(2, sharex=True)

    def _set_rsi(self):
        y = np.random.randint(100, size=self._t.shape)
        plot = self._ax1.plot(self._t, y, color = self._rsi_color)
        self._ax1.title.set_text('RSI data')
        self._ax1.grid()
        return plot

    def _set_dia(self):
        y = np.random.randint(100, size=self._t.shape)
        plot = self._ax2.plot(self._t, y, color = self._dia_color)
        self._ax2.title.set_text('Price chart')
        self._ax2.grid()
        return plot

    def _set_threshold(self):
        plot_rsi = self._set_rsi()
        plot_dia = self._set_dia()
        y_data = [plot_rsi[i].get_ydata() for i in range(len(plot_rsi))]
        x_data = [plot_dia[i].get_xdata() for i in range(len(plot_dia))]

        x_coord_list_down, y_coord_list_down = list(), list()
        x_coord_list_up, y_coord_list_up = list(), list()
        for x, y in zip(x_data[0], y_data[0]):
            if y < self._min:
                x_coord_list_down.append(x)
                y_coord_list_down.append(y)
            elif y > self._max:
                x_coord_list_up.append(x)
                y_coord_list_up.append(y)
        return (x_coord_list_down, y_coord_list_down, x_coord_list_up, y_coord_list_up)

    def _set_arrow(self):
        x_coord_list_down, y_coord_list_down,\
        x_coord_list_up, y_coord_list_up = self._set_threshold()
        for x_coord, y_coord in zip(x_coord_list_down, y_coord_list_down):
            plt.plot(x_coord, y_coord, marker="v", color='red')
        for x_coord, y_coord in zip(x_coord_list_up, y_coord_list_up):
            plt.plot(x_coord, y_coord, marker="^", color='green')

    def show(self):
        self._set_arrow()
        multi = MultiCursor(self._fig.canvas, (self._ax1, self._ax2), color='r', lw=1)
        plt.show()
    
if __name__ == '__main__':
    t = np.array([date(2020, i+1, 1) for i in range(12)])
    minimum = 35
    maximum = 65
    rsi_color='#ff6600'
    dia_color='#2ab0ff'
    barplot = SetArrowOnPriceBasedOnRsi(t, minimum, maximum, rsi_color, dia_color)
    barplot.show()
    